@echo off
cd /d "%~dp0"
if not exist shots mkdir shots
start "Shots" /min powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0shots.ps1"
start "" code "%~dp0."
start "Check" cmd /k "cd /d "%~dp0" && flutter analyze && flutter test"
start "Server" cmd /k "cd /d "%~dp0" && flutter run -d web-server --web-port=5555"
