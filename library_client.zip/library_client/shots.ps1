# Снимки экрана для отчёта: делает снимок основного экрана, когда в папке
# shots появляется файл req_<имя>.txt, и сохраняет его как shots\<имя>.png.
# Останавливается файлом shots\stop.txt или через 2 часа.
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class DpiHelper {
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
}
"@
[DpiHelper]::SetProcessDPIAware() | Out-Null

$dir = Join-Path $PSScriptRoot 'shots'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
"started $(Get-Date -Format o)" | Out-File (Join-Path $dir 'watcher.log')
$deadline = (Get-Date).AddHours(2)

while ((Get-Date) -lt $deadline) {
  if (Test-Path (Join-Path $dir 'stop.txt')) { break }
  foreach ($req in Get-ChildItem -Path $dir -Filter 'req_*.txt') {
    $name = $req.BaseName.Substring(4)
    Start-Sleep -Milliseconds 400
    $bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
    $bmp = New-Object System.Drawing.Bitmap $bounds.Width, $bounds.Height
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.CopyFromScreen($bounds.Location, [System.Drawing.Point]::Empty, $bounds.Size)
    $bmp.Save((Join-Path $dir "$name.png"), [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose()
    $bmp.Dispose()
    Remove-Item -LiteralPath $req.FullName -Force
    "$name $(Get-Date -Format o)" | Out-File -Append (Join-Path $dir 'watcher.log')
  }
  Start-Sleep -Milliseconds 300
}
"stopped $(Get-Date -Format o)" | Out-File -Append (Join-Path $dir 'watcher.log')
