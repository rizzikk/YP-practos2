@echo off
chcp 65001 >nul
cd /d "%~dp0"
set LOG=check_log.txt
echo ==== where flutter ==== > %LOG%
where flutter >> %LOG% 2>&1
echo ==== flutter --version ==== >> %LOG%
call flutter --version >> %LOG% 2>&1
echo ==== flutter pub get ==== >> %LOG%
call flutter pub get >> %LOG% 2>&1
echo ==== flutter analyze ==== >> %LOG%
call flutter analyze >> %LOG% 2>&1
echo ==== flutter test ==== >> %LOG%
call flutter test >> %LOG% 2>&1
echo ==== DONE ==== >> %LOG%
