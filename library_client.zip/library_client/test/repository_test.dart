import 'package:flutter_test/flutter_test.dart';
import 'package:library_client/models/author_query.dart';
import 'package:library_client/models/book_query.dart';
import 'package:library_client/repositories/in_memory_author_repository.dart';
import 'package:library_client/repositories/in_memory_book_repository.dart';

void main() {
  group('InMemoryBookRepository', () {
    late InMemoryBookRepository repo;

    setUp(() => repo = InMemoryBookRepository());

    test('удалённые записи по умолчанию скрыты', () async {
      final active = await repo.find(const BookQuery(size: 50));
      final all = await repo.find(const BookQuery(size: 50, includeDeleted: true));
      expect(active.total, 24);
      expect(all.total, 25);
      expect(active.items.any((b) => b.isDeleted), isFalse);
    });

    test('поиск по названию и по ISBN без учёта регистра', () async {
      final byTitle = await repo.find(const BookQuery(search: 'МАСТЕР'));
      expect(byTitle.items.map((b) => b.title), ['Мастер и Маргарита']);

      final byIsbn = await repo.find(const BookQuery(search: '978-5-389'));
      expect(byIsbn.total, 4);
    });

    test('фильтры комбинируются между собой и с поиском', () async {
      const q = BookQuery(genreId: 3, publisherId: 1, yearFrom: 2019, yearTo: 2021);
      final r = await repo.find(q);
      expect(r.items, isNotEmpty);
      for (final b in r.items) {
        expect(b.genreIds, contains(3));
        expect(b.publisherId, 1);
        expect(b.year, inInclusiveRange(2019, 2021));
      }
      final withSearch = await repo.find(q.copyWith(search: 'пикник'));
      expect(withSearch.items.map((b) => b.title), ['Пикник на обочине']);
    });

    test('сортировка по году по убыванию', () async {
      final r = await repo.find(
          const BookQuery(sortField: 'year', sortAscending: false, size: 50));
      final years = r.items.map((b) => b.year).toList();
      expect(years, [...years]..sort((a, b) => b.compareTo(a)));
    });

    test('пагинация', () async {
      final r = await repo.find(const BookQuery(page: 3, size: 10));
      expect(r.totalPages, 3);
      expect(r.items.length, 4);
      expect(r.hasNext, isFalse);
      expect(r.hasPrevious, isTrue);
      final beyond = await repo.find(const BookQuery(page: 9, size: 10));
      expect(beyond.items, isEmpty);
    });

    test('deleteMany удаляет только активные и возвращает их число', () async {
      await repo.softDelete(1);
      final count = await repo.deleteMany([1, 2, 3, 999]);
      expect(count, 2);
      expect((await repo.findById(2))!.isDeleted, isTrue);
    });

    test('restore снимает отметку, hardDelete стирает запись', () async {
      await repo.softDelete(5);
      await repo.restore(5);
      expect((await repo.findById(5))!.isDeleted, isFalse);
      await repo.hardDelete(5);
      expect(await repo.findById(5), isNull);
    });

    test('имитация сбоя', () async {
      await expectLater(
          repo.find(const BookQuery(search: '!error')), throwsException);
    });
  });

  group('InMemoryAuthorRepository', () {
    test('поиск по фамилии и стране', () async {
      final repo = InMemoryAuthorRepository();
      final byName = await repo.find(const AuthorQuery(search: 'стругацк'));
      expect(byName.total, 2);
      final byCountry = await repo.find(const AuthorQuery(search: 'сша'));
      expect(byCountry.total, 2);
    });
  });

  group('BookQuery', () {
    test('изменение условий возвращает на первую страницу', () {
      final q = const BookQuery(page: 5).copyWith(search: 'война');
      expect(q.page, 1);
    });

    test('null сбрасывает фильтр, отсутствие параметра — сохраняет', () {
      const q = BookQuery(genreId: 2);
      expect(q.copyWith(genreId: null).genreId, isNull);
      expect(q.copyWith(search: 'а').genreId, 2);
    });

    test('условия переживают круг «объект → адрес → объект»', () {
      const q = BookQuery(
        search: 'война',
        genreId: 2,
        sortField: 'year',
        sortAscending: false,
        page: 3,
      );
      final params = q.toQueryParameters();
      expect(params['sort'], 'year,desc');
      expect(params.containsKey('size'), isFalse);
      expect(BookQuery.fromQueryParameters(params), q);
    });

    test('некорректные параметры заменяются значениями по умолчанию', () {
      final q = BookQuery.fromQueryParameters(const {
        'page': '-4',
        'size': '7',
        'sort': 'hack,desc',
        'genreId': 'abc',
      });
      expect(q.page, 1);
      expect(q.size, 10);
      expect(q.sortField, 'title');
      expect(q.sortAscending, isFalse);
      expect(q.genreId, isNull);
    });
  });
}
