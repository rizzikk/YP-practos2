import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:library_client/widgets/entity_table.dart';

typedef Item = ({int id, String name, int size});

void main() {
  const rows = <Item>[
    (id: 1, name: 'Альфа', size: 10),
    (id: 2, name: 'Бета', size: 20),
  ];

  String? sortedBy;
  final toggled = <int>[];

  Widget host() => MaterialApp(
        home: Scaffold(
          body: EntityTable<Item>(
            items: rows,
            idOf: (r) => r.id,
            onToggleSelect: toggled.add,
            sortField: 'name',
            onSort: (field) => sortedBy = field,
            columns: [
              TableColumnSpec(
                  label: 'Имя', sortField: 'name', build: (r) => Text(r.name)),
              TableColumnSpec(
                  label: 'Размер',
                  sortField: 'size',
                  numeric: true,
                  build: (r) => Text('${r.size}')),
            ],
          ),
        ),
      );

  setUp(() {
    sortedBy = null;
    toggled.clear();
  });

  testWidgets('на широком окне — таблица с сортировкой по заголовку',
      (tester) async {
    tester.view.physicalSize = const Size(1200, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);

    await tester.pumpWidget(host());
    expect(find.byType(DataTable), findsOneWidget);
    expect(find.text('Альфа'), findsOneWidget);

    await tester.tap(find.text('Размер'));
    expect(sortedBy, 'size');
  });

  testWidgets('на узком окне — карточки с флажками', (tester) async {
    tester.view.physicalSize = const Size(400, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);

    await tester.pumpWidget(host());
    expect(find.byType(DataTable), findsNothing);
    expect(find.byType(Card), findsNWidgets(2));

    await tester.tap(find.byType(Checkbox).last);
    expect(toggled, [2]);
  });
}
