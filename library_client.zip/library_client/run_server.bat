@echo off
cd /d "%~dp0"
title Server
echo ===== flutter analyze =====
call flutter analyze
echo.
echo ===== flutter test =====
call flutter test --reporter expanded
echo.
echo ===== flutter run -d web-server --web-port=5555 =====
call flutter run -d web-server --web-port=5555
pause
