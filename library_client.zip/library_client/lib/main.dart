import 'package:flutter/material.dart';
import 'package:flutter_web_plugins/url_strategy.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'repositories/author_repository.dart';
import 'repositories/book_repository.dart';
import 'repositories/in_memory_author_repository.dart';
import 'repositories/in_memory_book_repository.dart';
import 'repositories/in_memory_reference_repository.dart';
import 'repositories/reference_repository.dart';
import 'state/author_list_notifier.dart';
import 'state/book_list_notifier.dart';
import 'state/catalog_notifier.dart';

void main() {
  // Адреса без «#»: /books?page=2 вместо /#/books?page=2.
  usePathUrlStrategy();
  runApp(
    MultiProvider(
      providers: [
        // Слой данных. В ПР4 здесь появятся реализации поверх HTTP,
        // остальные слои не изменятся.
        Provider<BookRepository>(create: (_) => InMemoryBookRepository()),
        Provider<AuthorRepository>(create: (_) => InMemoryAuthorRepository()),
        Provider<ReferenceRepository>(
            create: (_) => InMemoryReferenceRepository()),
        // Слой состояния. Списки загружаются экранами по условиям из адреса.
        ChangeNotifierProvider(
          create: (context) => CatalogNotifier(
            context.read<ReferenceRepository>(),
            context.read<AuthorRepository>(),
          )..load(),
        ),
        ChangeNotifierProvider(
          create: (context) => BookListNotifier(context.read<BookRepository>()),
        ),
        ChangeNotifierProvider(
          create: (context) =>
              AuthorListNotifier(context.read<AuthorRepository>()),
        ),
      ],
      child: const LibraryApp(),
    ),
  );
}
