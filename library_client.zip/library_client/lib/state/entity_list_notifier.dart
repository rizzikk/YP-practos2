import 'package:flutter/foundation.dart';

import '../models/page_result.dart';
import '../repositories/crud_repository.dart';
import 'load_status.dart';

/// Состояние экрана списка: условия отбора, текущая страница, статус загрузки
/// и выделенные записи. Обобщён по типу записи [T] и типу условий [Q], поэтому
/// книги и авторы используют одну и ту же реализацию.
abstract class EntityListNotifier<T, Q> extends ChangeNotifier {
  EntityListNotifier(this._repository, Q initialQuery) : _query = initialQuery;

  final CrudRepository<T, Q> _repository;

  Q _query;
  PageResult<T> _result = PageResult<T>.empty();
  LoadStatus _status = LoadStatus.idle;
  String? _error;
  final Set<int> _selected = {};

  /// Номер последнего запроса. Ответ на устаревший запрос (условия успели
  /// смениться, пока он выполнялся) отбрасывается.
  int _request = 0;

  Q get query => _query;
  PageResult<T> get result => _result;
  LoadStatus get status => _status;
  String? get error => _error;
  Set<int> get selected => Set.unmodifiable(_selected);
  bool get hasSelection => _selected.isNotEmpty;

  Future<void> load() async {
    final request = ++_request;
    _status = LoadStatus.loading;
    _error = null;
    notifyListeners();

    try {
      final result = await _repository.find(_query);
      if (request != _request) return;
      _result = result;
      _status = LoadStatus.success;
    } catch (e) {
      if (request != _request) return;
      _error = 'Не удалось загрузить список: $e';
      _status = LoadStatus.error;
    }
    // Вызов и в конце загрузки, иначе индикатор не исчезнет.
    notifyListeners();
  }

  Future<void> applyQuery(Q next) async {
    _query = next;
    _selected.clear(); // выделение теряет смысл при смене условий отбора
    await load();
  }

  /// Синхронизация с адресом: перезапрос только если условия действительно
  /// изменились (или список ещё не загружался).
  Future<void> syncWithQuery(Q next) async {
    if (next == _query && _status != LoadStatus.idle) return;
    await applyQuery(next);
  }

  void toggleSelection(int id) {
    if (!_selected.remove(id)) _selected.add(id);
    notifyListeners();
  }

  /// Выделить или снять выделение со всех записей текущей страницы.
  void setSelection(Iterable<int> ids, bool value) {
    if (value) {
      _selected.addAll(ids);
    } else {
      _selected.removeAll(ids);
    }
    notifyListeners();
  }

  void clearSelection() {
    _selected.clear();
    notifyListeners();
  }

  /// Логическое удаление выбранных. Возвращает число реально удалённых.
  Future<int> deleteSelected() async {
    final count = await _repository.deleteMany(_selected.toList());
    _selected.clear();
    await load();
    return count;
  }

  Future<void> softDelete(int id) async {
    await _repository.softDelete(id);
    _selected.remove(id);
    await load();
  }

  Future<void> hardDelete(int id) async {
    await _repository.hardDelete(id);
    _selected.remove(id);
    await load();
  }

  Future<void> restore(int id) async {
    await _repository.restore(id);
    await load();
  }
}
