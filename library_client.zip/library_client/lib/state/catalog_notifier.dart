import 'package:flutter/foundation.dart';

import '../models/author.dart';
import '../models/genre.dart';
import '../models/publisher.dart';
import '../repositories/author_repository.dart';
import '../repositories/reference_repository.dart';
import 'load_status.dart';

/// Справочники: жанры, издательства, имена авторов. Нужны для выпадающих
/// списков фильтров и для вывода названий вместо идентификаторов.
class CatalogNotifier extends ChangeNotifier {
  CatalogNotifier(this._references, this._authors);

  final ReferenceRepository _references;
  final AuthorRepository _authors;

  Map<int, Genre> _genres = const {};
  Map<int, Publisher> _publishers = const {};
  Map<int, Author> _authorsById = const {};
  LoadStatus _status = LoadStatus.idle;

  LoadStatus get status => _status;
  List<Genre> get genres => _genres.values.toList()
    ..sort((a, b) => a.name.compareTo(b.name));
  List<Publisher> get publishers => _publishers.values.toList()
    ..sort((a, b) => a.name.compareTo(b.name));
  List<String> get countries =>
      _authorsById.values.map((a) => a.country).toSet().toList()..sort();

  Future<void> load() async {
    _status = LoadStatus.loading;
    notifyListeners();
    try {
      final genres = await _references.genres();
      final publishers = await _references.publishers();
      final authors = await _authors.findAll();
      _genres = {for (final g in genres) g.id: g};
      _publishers = {for (final p in publishers) p.id: p};
      _authorsById = {for (final a in authors) a.id: a};
      _status = LoadStatus.success;
    } catch (_) {
      _status = LoadStatus.error;
    }
    notifyListeners();
  }

  Author? author(int id) => _authorsById[id];
  Publisher? publisher(int id) => _publishers[id];

  String genreNames(List<int> ids) =>
      _join(ids.map((id) => _genres[id]?.name ?? '#$id'));

  String publisherName(int id) => _publishers[id]?.name ?? '#$id';

  String authorNames(List<int> ids) =>
      _join(ids.map((id) => _authorsById[id]?.shortName ?? 'автор #$id'));

  static String _join(Iterable<String> parts) =>
      parts.isEmpty ? '—' : parts.join(', ');
}
