import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../models/author.dart';
import '../models/author_query.dart';
import '../router/locations.dart';
import '../state/author_list_notifier.dart';
import '../state/catalog_notifier.dart';
import '../state/load_status.dart';
import '../widgets/debounced_text_field.dart';
import '../widgets/deleted_badge.dart';
import '../widgets/dialogs.dart';
import '../widgets/entity_table.dart';
import '../widgets/labeled_dropdown.dart';
import '../widgets/pagination_bar.dart';
import '../widgets/selection_bar.dart';
import '../widgets/state_views.dart';

/// Список авторов. Устроен так же, как список книг, и использует ту же
/// таблицу [EntityTable] — отличается только описанием колонок и фильтров.
class AuthorsListScreen extends StatefulWidget {
  final AuthorQuery query;

  const AuthorsListScreen({super.key, required this.query});

  @override
  State<AuthorsListScreen> createState() => _AuthorsListScreenState();
}

class _AuthorsListScreenState extends State<AuthorsListScreen> {
  bool _filtersExpanded = false;

  AuthorQuery get _q => widget.query;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<AuthorListNotifier>().applyQuery(_q);
    });
  }

  @override
  void didUpdateWidget(AuthorsListScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.query != widget.query) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) context.read<AuthorListNotifier>().syncWithQuery(_q);
      });
    }
  }

  void _go(AuthorQuery next) {
    if (next == _q) return;
    context.go(authorsLocation(next));
  }

  void _sort(String field) => _go(_q.copyWith(
        sortField: field,
        sortAscending: field == _q.sortField ? !_q.sortAscending : true,
      ));

  void _fixPageOverflow(AuthorListNotifier list) {
    final r = list.result;
    if (list.status == LoadStatus.success &&
        r.items.isEmpty &&
        r.total > 0 &&
        list.query.page > r.totalPages) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _go(_q.copyWith(page: r.totalPages));
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final list = context.watch<AuthorListNotifier>();
    final catalog = context.watch<CatalogNotifier>();
    final result = list.result;
    final narrow = MediaQuery.sizeOf(context).width < EntityTable.cardBreakpoint;
    _fixPageOverflow(list);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Авторы'),
        actions: [
          IconButton(
            tooltip: 'Обновить',
            icon: const Icon(Icons.refresh),
            onPressed: list.load,
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildFilters(catalog, narrow),
          if (list.hasSelection)
            SelectionBar(
              count: list.selected.length,
              onDelete: () => _deleteSelected(list),
              onClear: list.clearSelection,
            ),
          Expanded(
            child: ListStateView(
              status: list.status,
              error: list.error,
              hasData: result.items.isNotEmpty,
              emptyTitle: _q.hasFilters ? 'Ничего не найдено' : 'Авторов нет',
              emptyMessage: _q.hasFilters
                  ? 'Ни один автор не подходит под условия отбора.'
                  : 'В каталоге пока нет ни одного автора.',
              onRetry: list.load,
              onResetFilters: _q.hasFilters ? () => _go(_q.clearFilters()) : null,
              child: _buildTable(list),
            ),
          ),
          if (list.status != LoadStatus.error && result.total > 0)
            PaginationBar(
              result: result,
              size: _q.size,
              onPage: (page) => _go(_q.copyWith(page: page)),
              onSize: (size) => _go(_q.copyWith(size: size)),
            ),
        ],
      ),
    );
  }

  Widget _buildFilters(CatalogNotifier catalog, bool narrow) {
    final search = DebouncedTextField(
      value: _q.search,
      label: 'Поиск',
      hint: 'Фамилия или страна',
      icon: Icons.search,
      width: narrow ? null : 300,
      onChanged: (v) => _go(_q.copyWith(search: v)),
    );
    final filters = <Widget>[
      LabeledDropdown<String>(
        label: 'Страна',
        anyLabel: 'Все страны',
        width: narrow ? null : 220,
        value: _q.country,
        options: {for (final c in catalog.countries) c: c},
        onChanged: (v) => _go(_q.copyWith(country: v)),
      ),
      FilterChip(
        label: const Text('Показывать удалённых'),
        selected: _q.includeDeleted,
        onSelected: (v) => _go(_q.copyWith(includeDeleted: v)),
      ),
      if (_q.hasFilters)
        TextButton.icon(
          onPressed: () => _go(_q.clearFilters()),
          icon: const Icon(Icons.filter_alt_off),
          label: const Text('Сбросить'),
        ),
    ];

    if (!narrow) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
        child: Wrap(
          spacing: 12,
          runSpacing: 12,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [search, ...filters],
        ),
      );
    }

    final count = _q.activeFilterCount;
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(child: search),
              IconButton(
                tooltip: 'Фильтры',
                isSelected: _filtersExpanded,
                icon: Badge(
                  isLabelVisible: count > 0,
                  label: Text('$count'),
                  child: const Icon(Icons.tune),
                ),
                onPressed: () =>
                    setState(() => _filtersExpanded = !_filtersExpanded),
              ),
            ],
          ),
          if (_filtersExpanded)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Wrap(spacing: 8, runSpacing: 8, children: filters),
            ),
        ],
      ),
    );
  }

  Widget _buildTable(AuthorListNotifier list) {
    final items = list.result.items;
    return EntityTable<Author>(
      items: items,
      idOf: (a) => a.id,
      isInactive: (a) => a.isDeleted,
      selected: list.selected,
      onToggleSelect: list.toggleSelection,
      onSelectAll: (value) => list.setSelection(items.map((a) => a.id), value),
      sortField: _q.sortField,
      sortAscending: _q.sortAscending,
      onSort: _sort,
      onOpen: (a) => context.go(authorLocation(a.id)),
      columns: [
        TableColumnSpec(
          label: 'ФИО',
          sortField: 'lastName',
          build: (a) => TitleWithBadge(text: a.fullName, deleted: a.isDeleted),
        ),
        TableColumnSpec(
          label: 'Страна',
          sortField: 'country',
          build: (a) => Text(a.country),
        ),
        TableColumnSpec(
          label: 'Годы жизни',
          sortField: 'birthYear',
          build: (a) => Text(a.lifeYears),
        ),
      ],
      actions: (a) => _rowActions(list, a),
    );
  }

  List<Widget> _rowActions(AuthorListNotifier list, Author a) {
    if (a.isDeleted) {
      return [
        IconButton(
          tooltip: 'Восстановить',
          icon: const Icon(Icons.restore_from_trash),
          onPressed: () => runWithFeedback(
            context,
            () => list.restore(a.id),
            success: 'Автор «${a.fullName}» восстановлен',
          ),
        ),
        IconButton(
          tooltip: 'Удалить навсегда',
          icon: Icon(Icons.delete_forever,
              color: Theme.of(context).colorScheme.error),
          onPressed: () => _hardDelete(list, a),
        ),
      ];
    }
    return [
      IconButton(
        tooltip: 'Открыть карточку',
        icon: const Icon(Icons.open_in_new),
        onPressed: () => context.go(authorLocation(a.id)),
      ),
      IconButton(
        tooltip: 'Удалить',
        icon: const Icon(Icons.delete_outline),
        onPressed: () => _softDelete(list, a),
      ),
    ];
  }

  Future<void> _softDelete(AuthorListNotifier list, Author a) async {
    final ok = await confirmAction(
      context,
      title: 'Удалить автора?',
      message: '«${a.fullName}» будет помечен как удалённый. '
          'Запись можно восстановить, включив показ удалённых.',
    );
    if (!ok) return;
    if (!mounted) return;
    await runWithFeedback(context, () => list.softDelete(a.id),
        success: 'Автор «${a.fullName}» удалён');
  }

  Future<void> _hardDelete(AuthorListNotifier list, Author a) async {
    final ok = await confirmAction(
      context,
      title: 'Удалить навсегда?',
      message: '«${a.fullName}» будет стёрт без возможности восстановления.',
      confirmLabel: 'Удалить навсегда',
    );
    if (!ok) return;
    if (!mounted) return;
    final catalog = context.read<CatalogNotifier>();
    final done = await runWithFeedback(context, () => list.hardDelete(a.id),
        success: 'Автор «${a.fullName}» удалён навсегда');
    // Справочник имён больше не должен содержать стёртого автора.
    if (done) await catalog.load();
  }

  Future<void> _deleteSelected(AuthorListNotifier list) async {
    final count = list.selected.length;
    final ok = await confirmAction(
      context,
      title: 'Удалить выбранных авторов?',
      message: 'Выбрано записей: $count. Они будут помечены как удалённые; '
          'уже удалённые записи пропускаются.',
      confirmLabel: 'Удалить ($count)',
    );
    if (!ok) return;
    if (!mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    try {
      final deleted = await list.deleteSelected();
      messenger
          .showSnackBar(SnackBar(content: Text('Удалено авторов: $deleted')));
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('Ошибка: $e')));
    }
  }
}
