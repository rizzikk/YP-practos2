import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../router/locations.dart';
import '../state/author_list_notifier.dart';
import '../state/book_list_notifier.dart';

/// Общая оболочка: боковая навигация на широком окне, нижняя — на узком.
class AppShell extends StatelessWidget {
  final String location;
  final Widget child;

  const AppShell({super.key, required this.location, required this.child});

  int get _index => location.startsWith('/authors') ? 1 : 0;

  void _select(BuildContext context, int index) {
    // Возврат к разделу восстанавливает его последние условия отбора.
    if (index == 0) {
      context.go(booksLocation(context.read<BookListNotifier>().query));
    } else {
      context.go(authorsLocation(context.read<AuthorListNotifier>().query));
    }
  }

  @override
  Widget build(BuildContext context) {
    final narrow = MediaQuery.sizeOf(context).width < 600;
    if (narrow) {
      return Scaffold(
        body: child,
        bottomNavigationBar: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (i) => _select(context, i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.menu_book), label: 'Книги'),
            NavigationDestination(icon: Icon(Icons.person), label: 'Авторы'),
          ],
        ),
      );
    }
    return Scaffold(
      body: Row(
        children: [
          NavigationRail(
            selectedIndex: _index,
            onDestinationSelected: (i) => _select(context, i),
            labelType: NavigationRailLabelType.all,
            leading: const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Icon(Icons.local_library, size: 32),
            ),
            destinations: const [
              NavigationRailDestination(
                  icon: Icon(Icons.menu_book), label: Text('Книги')),
              NavigationRailDestination(
                  icon: Icon(Icons.person), label: Text('Авторы')),
            ],
          ),
          const VerticalDivider(width: 1),
          Expanded(child: child),
        ],
      ),
    );
  }
}
