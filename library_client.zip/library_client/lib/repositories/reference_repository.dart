import '../models/genre.dart';
import '../models/publisher.dart';

/// Справочники, нужные для фильтров и отображения названий.
abstract interface class ReferenceRepository {
  Future<List<Genre>> genres();
  Future<List<Publisher>> publishers();
}
