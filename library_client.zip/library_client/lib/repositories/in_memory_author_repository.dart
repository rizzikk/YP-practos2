import '../models/author.dart';
import '../models/author_query.dart';
import '../models/page_result.dart';
import 'author_repository.dart';
import 'in_memory_support.dart';
import 'seed_data.dart';

class InMemoryAuthorRepository implements AuthorRepository {
  final List<Author> _authors = [...seedAuthors];
  int _nextId = seedAuthors.length + 1;

  @override
  Future<PageResult<Author>> find(AuthorQuery q) async {
    await Future.delayed(simulatedLatency);
    throwIfFailureRequested(q.search);

    var rows =
        _authors.where((a) => q.includeDeleted || !a.isDeleted).toList();

    // Поиск по фамилии и стране (п. 8 задания).
    if (q.search.trim().isNotEmpty) {
      final needle = q.search.trim().toLowerCase();
      rows = rows
          .where((a) =>
              a.lastName.toLowerCase().contains(needle) ||
              a.country.toLowerCase().contains(needle))
          .toList();
    }
    if (q.country != null) {
      rows = rows.where((a) => a.country == q.country).toList();
    }

    int byName(Author a, Author b) {
      final r = a.lastName.toLowerCase().compareTo(b.lastName.toLowerCase());
      return r != 0
          ? r
          : a.firstName.toLowerCase().compareTo(b.firstName.toLowerCase());
    }

    rows.sort((a, b) {
      final primary = switch (q.sortField) {
        'country' => a.country.compareTo(b.country),
        'birthYear' => a.birthYear.compareTo(b.birthYear),
        _ => byName(a, b),
      };
      final secondary = primary != 0 ? primary : byName(a, b);
      final stable = secondary != 0 ? secondary : a.id.compareTo(b.id);
      return q.sortAscending ? stable : -stable;
    });

    return paginate(rows, page: q.page, size: q.size);
  }

  @override
  Future<List<Author>> findAll() async => List.unmodifiable(_authors);

  @override
  Future<Author?> findById(int id) async {
    await Future.delayed(simulatedLatency);
    final i = _authors.indexWhere((a) => a.id == id);
    return i == -1 ? null : _authors[i];
  }

  @override
  Future<Author> create(Author author) async {
    final created = author.withId(_nextId++);
    _authors.add(created);
    return created;
  }

  @override
  Future<Author> update(Author author) async {
    final i = _authors.indexWhere((a) => a.id == author.id);
    if (i == -1) throw StateError('Автор ${author.id} не найден');
    _authors[i] = author;
    return author;
  }

  @override
  Future<void> softDelete(int id) async {
    final i = _authors.indexWhere((a) => a.id == id);
    if (i == -1) throw StateError('Автор $id не найден');
    _authors[i] = _authors[i].copyWith(deletedAt: DateTime.now());
  }

  @override
  Future<void> hardDelete(int id) async {
    _authors.removeWhere((a) => a.id == id);
  }

  @override
  Future<void> restore(int id) async {
    final i = _authors.indexWhere((a) => a.id == id);
    if (i == -1) throw StateError('Автор $id не найден');
    _authors[i] = _authors[i].copyWith(clearDeletedAt: true);
  }

  @override
  Future<int> deleteMany(List<int> ids) async {
    var count = 0;
    for (final id in ids) {
      final i = _authors.indexWhere((a) => a.id == id && !a.isDeleted);
      if (i != -1) {
        _authors[i] = _authors[i].copyWith(deletedAt: DateTime.now());
        count++;
      }
    }
    return count;
  }
}
