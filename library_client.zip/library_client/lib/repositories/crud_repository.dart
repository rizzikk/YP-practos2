import '../models/page_result.dart';

/// Общий контракт хранилища сущности: что приложение умеет делать с записями,
/// безотносительно того, где они лежат (в памяти сейчас, на сервере в ПР4).
abstract interface class CrudRepository<T, Q> {
  Future<PageResult<T>> find(Q query);
  Future<T?> findById(int id);
  Future<T> create(T entity);
  Future<T> update(T entity);
  Future<void> softDelete(int id);
  Future<void> hardDelete(int id);
  Future<void> restore(int id);
  Future<int> deleteMany(List<int> ids);
}
