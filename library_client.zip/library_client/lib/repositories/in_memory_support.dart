import '../models/page_result.dart';

/// Небольшая задержка имитирует сеть: без неё индикатор загрузки
/// невозможно увидеть, а в ПР4 он понадобится по-настоящему.
const Duration simulatedLatency = Duration(milliseconds: 250);

/// Поисковая строка, при которой репозиторий в памяти имитирует сбой.
/// Нужна, чтобы показать состояние ошибки без сервера.
const String simulatedFailureTrigger = '!error';

void throwIfFailureRequested(String search) {
  if (search.trim() == simulatedFailureTrigger) {
    throw Exception('источник данных недоступен (имитация сбоя)');
  }
}

/// Нарезка отсортированной выборки на страницы — общая для всех репозиториев.
PageResult<T> paginate<T>(List<T> rows, {required int page, required int size}) {
  final total = rows.length;
  final from = (page - 1) * size;
  // Осторожно: num.clamp возвращает num, а не int, и в sublist его
  // передать нельзя. Границу считаем явно.
  final to = (from + size) > total ? total : (from + size);
  final items = from >= total ? <T>[] : rows.sublist(from, to);
  return PageResult(items: items, page: page, size: size, total: total);
}
