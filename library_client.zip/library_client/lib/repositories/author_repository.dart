import '../models/author.dart';
import '../models/author_query.dart';
import 'crud_repository.dart';

abstract interface class AuthorRepository
    implements CrudRepository<Author, AuthorQuery> {
  /// Все авторы, включая удалённые, — для справочника имён.
  Future<List<Author>> findAll();
}
