import '../models/author.dart';
import '../models/book.dart';
import '../models/genre.dart';
import '../models/publisher.dart';

/// Начальный набор данных. При перезагрузке страницы данные восстанавливаются
/// именно из него.
const List<Genre> seedGenres = [
  Genre(id: 1, name: 'Роман'),
  Genre(id: 2, name: 'Военная проза'),
  Genre(id: 3, name: 'Фантастика'),
  Genre(id: 4, name: 'Антиутопия'),
  Genre(id: 5, name: 'Повесть'),
  Genre(id: 6, name: 'Драматургия'),
  Genre(id: 7, name: 'Поэзия'),
];

const List<Publisher> seedPublishers = [
  Publisher(id: 1, name: 'АСТ', city: 'Москва'),
  Publisher(id: 2, name: 'Эксмо', city: 'Москва'),
  Publisher(id: 3, name: 'Азбука', city: 'Санкт-Петербург'),
  Publisher(id: 4, name: 'Питер', city: 'Санкт-Петербург'),
  Publisher(id: 5, name: 'Просвещение', city: 'Москва'),
];

const List<Author> seedAuthors = [
  Author(id: 1, lastName: 'Толстой', firstName: 'Лев', middleName: 'Николаевич', country: 'Россия', birthYear: 1828, deathYear: 1910),
  Author(id: 2, lastName: 'Достоевский', firstName: 'Фёдор', middleName: 'Михайлович', country: 'Россия', birthYear: 1821, deathYear: 1881),
  Author(id: 3, lastName: 'Чехов', firstName: 'Антон', middleName: 'Павлович', country: 'Россия', birthYear: 1860, deathYear: 1904),
  Author(id: 4, lastName: 'Булгаков', firstName: 'Михаил', middleName: 'Афанасьевич', country: 'СССР', birthYear: 1891, deathYear: 1940),
  Author(id: 5, lastName: 'Пушкин', firstName: 'Александр', middleName: 'Сергеевич', country: 'Россия', birthYear: 1799, deathYear: 1837),
  Author(id: 6, lastName: 'Гоголь', firstName: 'Николай', middleName: 'Васильевич', country: 'Россия', birthYear: 1809, deathYear: 1852),
  Author(id: 7, lastName: 'Оруэлл', firstName: 'Джордж', country: 'Великобритания', birthYear: 1903, deathYear: 1950),
  Author(id: 8, lastName: 'Ремарк', firstName: 'Эрих Мария', country: 'Германия', birthYear: 1898, deathYear: 1970),
  Author(id: 9, lastName: 'Хемингуэй', firstName: 'Эрнест', country: 'США', birthYear: 1899, deathYear: 1961),
  Author(id: 10, lastName: 'Брэдбери', firstName: 'Рэй', country: 'США', birthYear: 1920, deathYear: 2012),
  Author(id: 11, lastName: 'Стругацкий', firstName: 'Аркадий', middleName: 'Натанович', country: 'СССР', birthYear: 1925, deathYear: 1991),
  Author(id: 12, lastName: 'Стругацкий', firstName: 'Борис', middleName: 'Натанович', country: 'СССР', birthYear: 1933, deathYear: 2012),
];

final List<Book> seedBooks = [
  const Book(id: 1, title: 'Война и мир', isbn: '978-5-17-090101-1', year: 2019, pages: 1300, publisherId: 1, authorIds: [1], genreIds: [1, 2], copiesTotal: 5, copiesAvailable: 3),
  const Book(id: 2, title: 'Анна Каренина', isbn: '978-5-04-090102-2', year: 2020, pages: 864, publisherId: 2, authorIds: [1], genreIds: [1], copiesTotal: 4, copiesAvailable: 4),
  const Book(id: 3, title: 'Преступление и наказание', isbn: '978-5-389-09010-3', year: 2018, pages: 592, publisherId: 3, authorIds: [2], genreIds: [1], copiesTotal: 6, copiesAvailable: 2),
  const Book(id: 4, title: 'Идиот', isbn: '978-5-389-09010-4', year: 2021, pages: 640, publisherId: 3, authorIds: [2], genreIds: [1], copiesTotal: 3, copiesAvailable: 1),
  const Book(id: 5, title: 'Братья Карамазовы', isbn: '978-5-17-090105-5', year: 2017, pages: 992, publisherId: 1, authorIds: [2], genreIds: [1], copiesTotal: 3, copiesAvailable: 0),
  const Book(id: 6, title: 'Вишнёвый сад', isbn: '978-5-09-090106-6', year: 2016, pages: 128, publisherId: 5, authorIds: [3], genreIds: [6], copiesTotal: 8, copiesAvailable: 7),
  const Book(id: 7, title: 'Палата № 6', isbn: '978-5-04-090107-7', year: 2019, pages: 160, publisherId: 2, authorIds: [3], genreIds: [5], copiesTotal: 2, copiesAvailable: 2),
  const Book(id: 8, title: 'Мастер и Маргарита', isbn: '978-5-17-090108-8', year: 2022, pages: 480, publisherId: 1, authorIds: [4], genreIds: [1, 3], copiesTotal: 7, copiesAvailable: 1),
  const Book(id: 9, title: 'Собачье сердце', isbn: '978-5-04-090109-9', year: 2020, pages: 192, publisherId: 2, authorIds: [4], genreIds: [5, 3], copiesTotal: 4, copiesAvailable: 3),
  const Book(id: 10, title: 'Белая гвардия', isbn: '978-5-389-09011-0', year: 2015, pages: 384, publisherId: 3, authorIds: [4], genreIds: [1, 2], copiesTotal: 2, copiesAvailable: 2),
  const Book(id: 11, title: 'Евгений Онегин', isbn: '978-5-09-090111-1', year: 2018, pages: 320, publisherId: 5, authorIds: [5], genreIds: [7, 1], copiesTotal: 10, copiesAvailable: 9),
  const Book(id: 12, title: 'Капитанская дочка', isbn: '978-5-09-090112-2', year: 2014, pages: 224, publisherId: 5, authorIds: [5], genreIds: [5], copiesTotal: 10, copiesAvailable: 6),
  const Book(id: 13, title: 'Мёртвые души', isbn: '978-5-389-09011-3', year: 2016, pages: 416, publisherId: 3, authorIds: [6], genreIds: [1], copiesTotal: 4, copiesAvailable: 4),
  const Book(id: 14, title: 'Ревизор', isbn: '978-5-09-090114-4', year: 2013, pages: 160, publisherId: 5, authorIds: [6], genreIds: [6], copiesTotal: 6, copiesAvailable: 5),
  const Book(id: 15, title: '1984', isbn: '978-5-17-090115-5', year: 2021, pages: 320, publisherId: 1, authorIds: [7], genreIds: [4, 1], copiesTotal: 5, copiesAvailable: 0),
  // Одна запись удалена логически — чтобы переключатель «Показывать удалённые»
  // и восстановление можно было проверить сразу.
  Book(id: 16, title: 'Скотный двор', isbn: '978-5-17-090116-6', year: 2020, pages: 128, publisherId: 1, authorIds: const [7], genreIds: const [4, 5], copiesTotal: 3, copiesAvailable: 3, deletedAt: DateTime(2026, 9, 14, 12, 30)),
  const Book(id: 17, title: 'На Западном фронте без перемен', isbn: '978-5-17-090117-7', year: 2019, pages: 304, publisherId: 1, authorIds: [8], genreIds: [1, 2], copiesTotal: 4, copiesAvailable: 2),
  const Book(id: 18, title: 'Три товарища', isbn: '978-5-17-090118-8', year: 2018, pages: 480, publisherId: 1, authorIds: [8], genreIds: [1], copiesTotal: 5, copiesAvailable: 5),
  const Book(id: 19, title: 'Прощай, оружие!', isbn: '978-5-17-090119-9', year: 2017, pages: 320, publisherId: 1, authorIds: [9], genreIds: [1, 2], copiesTotal: 3, copiesAvailable: 1),
  const Book(id: 20, title: 'Старик и море', isbn: '978-5-17-090120-0', year: 2022, pages: 128, publisherId: 1, authorIds: [9], genreIds: [5], copiesTotal: 4, copiesAvailable: 4),
  const Book(id: 21, title: '451° по Фаренгейту', isbn: '978-5-04-090121-1', year: 2023, pages: 256, publisherId: 2, authorIds: [10], genreIds: [3, 4], copiesTotal: 6, copiesAvailable: 2),
  const Book(id: 22, title: 'Марсианские хроники', isbn: '978-5-04-090122-2', year: 2021, pages: 320, publisherId: 2, authorIds: [10], genreIds: [3], copiesTotal: 3, copiesAvailable: 3),
  const Book(id: 23, title: 'Пикник на обочине', isbn: '978-5-17-090123-3', year: 2020, pages: 256, publisherId: 1, authorIds: [11, 12], genreIds: [3], copiesTotal: 4, copiesAvailable: 1),
  const Book(id: 24, title: 'Трудно быть богом', isbn: '978-5-17-090124-4', year: 2019, pages: 288, publisherId: 1, authorIds: [11, 12], genreIds: [3], copiesTotal: 3, copiesAvailable: 3),
  const Book(id: 25, title: 'Понедельник начинается в субботу', isbn: '978-5-4461-0125-5', year: 2016, pages: 352, publisherId: 4, authorIds: [11, 12], genreIds: [3], copiesTotal: 2, copiesAvailable: 0),
];
