import '../models/book.dart';
import '../models/book_query.dart';
import 'crud_repository.dart';

/// Операции с книгами: find, findById, create, update, softDelete,
/// hardDelete, restore, deleteMany — из [CrudRepository], плюс выборка по автору.
abstract interface class BookRepository
    implements CrudRepository<Book, BookQuery> {
  /// Все книги автора, включая удалённые (для карточки автора).
  Future<List<Book>> findByAuthor(int authorId);
}
