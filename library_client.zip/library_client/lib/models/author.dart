/// Автор. Неизменяемая модель: любое изменение — через [copyWith].
class Author {
  final int id;
  final String lastName;
  final String firstName;
  final String? middleName;
  final String country;
  final int birthYear;
  final int? deathYear;
  final DateTime? deletedAt;

  const Author({
    required this.id,
    required this.lastName,
    required this.firstName,
    this.middleName,
    required this.country,
    required this.birthYear,
    this.deathYear,
    this.deletedAt,
  });

  bool get isDeleted => deletedAt != null;

  /// «Толстой Лев Николаевич».
  String get fullName {
    final m = middleName;
    return m == null ? '$lastName $firstName' : '$lastName $firstName $m';
  }

  /// «Л. Толстой» — для компактного вывода в таблице книг.
  String get shortName =>
      firstName.isEmpty ? lastName : '${firstName.substring(0, 1)}. $lastName';

  String get lifeYears {
    final d = deathYear;
    return d == null ? 'род. $birthYear' : '$birthYear–$d';
  }

  /// Флаги `clear…` позволяют записать `null` в поле (см. [Book.copyWith]).
  Author copyWith({
    String? lastName,
    String? firstName,
    String? middleName,
    bool clearMiddleName = false,
    String? country,
    int? birthYear,
    int? deathYear,
    bool clearDeathYear = false,
    DateTime? deletedAt,
    bool clearDeletedAt = false,
  }) {
    return Author(
      id: id,
      lastName: lastName ?? this.lastName,
      firstName: firstName ?? this.firstName,
      middleName: clearMiddleName ? null : (middleName ?? this.middleName),
      country: country ?? this.country,
      birthYear: birthYear ?? this.birthYear,
      deathYear: clearDeathYear ? null : (deathYear ?? this.deathYear),
      deletedAt: clearDeletedAt ? null : (deletedAt ?? this.deletedAt),
    );
  }

  Author withId(int newId) => Author(
        id: newId,
        lastName: lastName,
        firstName: firstName,
        middleName: middleName,
        country: country,
        birthYear: birthYear,
        deathYear: deathYear,
        deletedAt: deletedAt,
      );
}
