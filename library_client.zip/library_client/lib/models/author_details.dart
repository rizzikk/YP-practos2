import 'author.dart';
import 'book.dart';

/// Данные карточки автора: сам автор и его книги в каталоге.
class AuthorDetails {
  final Author author;
  final List<Book> books;

  const AuthorDetails({required this.author, required this.books});
}
