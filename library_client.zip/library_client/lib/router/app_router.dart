import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../models/author_details.dart';
import '../models/author_query.dart';
import '../models/book.dart';
import '../models/book_query.dart';
import '../repositories/author_repository.dart';
import '../repositories/book_repository.dart';
import '../screens/app_shell.dart';
import '../screens/author_details_screen.dart';
import '../screens/authors_list_screen.dart';
import '../screens/book_details_screen.dart';
import '../screens/books_list_screen.dart';
import '../screens/not_found_screen.dart';
import '../state/details_notifier.dart';

/// Маршруты приложения. Адрес — единственный источник условий отбора:
/// экран списка получает их из параметров адреса, а не хранит у себя.
GoRouter createRouter() => GoRouter(
      initialLocation: '/books',
      errorBuilder: (context, state) =>
          NotFoundScreen(location: state.uri.toString()),
      routes: [
        GoRoute(path: '/', redirect: (context, state) => '/books'),
        ShellRoute(
          builder: (context, state, child) =>
              AppShell(location: state.uri.path, child: child),
          routes: [
            GoRoute(
              path: '/books',
              // Постоянный ключ страницы: при смене параметров экран
              // обновляется, а не пересоздаётся — поле поиска не теряет фокус.
              pageBuilder: (context, state) => NoTransitionPage(
                key: const ValueKey('books-list'),
                child: BooksListScreen(
                  query: BookQuery.fromQueryParameters(state.uri.queryParameters),
                ),
              ),
            ),
            GoRoute(
              path: '/books/:id',
              builder: (context, state) {
                final id = int.tryParse(state.pathParameters['id'] ?? '');
                if (id == null) {
                  return NotFoundScreen(location: state.uri.toString());
                }
                return ChangeNotifierProvider(
                  key: ValueKey('book-$id'),
                  create: (context) {
                    // Точка сборки: notifier получает репозиторий здесь,
                    // сам экран к репозиторию не обращается.
                    final books = context.read<BookRepository>();
                    return DetailsNotifier<Book>(() => books.findById(id))
                      ..load();
                  },
                  child: BookDetailsScreen(id: id),
                );
              },
            ),
            GoRoute(
              path: '/authors',
              pageBuilder: (context, state) => NoTransitionPage(
                key: const ValueKey('authors-list'),
                child: AuthorsListScreen(
                  query:
                      AuthorQuery.fromQueryParameters(state.uri.queryParameters),
                ),
              ),
            ),
            GoRoute(
              path: '/authors/:id',
              builder: (context, state) {
                final id = int.tryParse(state.pathParameters['id'] ?? '');
                if (id == null) {
                  return NotFoundScreen(location: state.uri.toString());
                }
                return ChangeNotifierProvider(
                  key: ValueKey('author-$id'),
                  create: (context) {
                    final authors = context.read<AuthorRepository>();
                    final books = context.read<BookRepository>();
                    return DetailsNotifier<AuthorDetails>(() async {
                      final author = await authors.findById(id);
                      if (author == null) return null;
                      return AuthorDetails(
                        author: author,
                        books: await books.findByAuthor(id),
                      );
                    })
                      ..load();
                  },
                  child: AuthorDetailsScreen(id: id),
                );
              },
            ),
          ],
        ),
      ],
    );
