import '../models/author_query.dart';
import '../models/book_query.dart';

/// Адрес списка с условиями отбора в параметрах:
/// `/books?search=война&genreId=2&sort=year,desc&page=3`.
String booksLocation(BookQuery query) =>
    _location('/books', query.toQueryParameters());

String authorsLocation(AuthorQuery query) =>
    _location('/authors', query.toQueryParameters());

String bookLocation(int id) => '/books/$id';
String authorLocation(int id) => '/authors/$id';

String _location(String path, Map<String, String> params) =>
    Uri(path: path, queryParameters: params.isEmpty ? null : params).toString();
